<template>  
  
<v-container >
  <!-- Homepage that contains the 2 buttons and the detective hat image-->
    <img src="../assets/images/detective_hat.png"
   class="ms-4 mt-8"> 
    <v-row class="mt-6">
      <v-col
        cols="12"
      >
          <v-btn-toggle style="flex-direction: column; width: 30%;" background-color="rgb(255, 0, 0, 0)">
          <v-btn style="font-size: 20px" v-bind="buttonsTheme" class="my-6" v-for="section in sections" :to="section.to" :key="section.title">{{ section.title }}</v-btn>
          </v-btn-toggle>
      </v-col>
    </v-row> 

    </v-container>
</template> 

<style scoped>
img{
  border: 0;
}
</style>
<script>
  import VueStar from 'vue-star'
  export default {
    name:'HomePage',
    components:{
      VueStar
    },
    data: () => ({ 
      sections: [
        { title: ' Quiz ', to:'/quiz'},
        {title: ' Play ', to:'/game'}
      ] 
      }),
      computed:{
        buttonsTheme(){
          return this.$store.state.buttonsTheme;
        }
      },
  }
</script>
