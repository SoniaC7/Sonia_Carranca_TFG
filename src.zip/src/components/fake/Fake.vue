<template>
    <div class="fake"> 
        <h1 class="mb-3 mt-3" v-show="!this.option_selected"> Fake Photos</h1>
        <v-row align="center" v-show="!this.option_selected" >
            <v-col
                cols="12"
            >
                <v-btn-toggle style="flex-direction: column;" background-color="rgb(255, 0, 0, 0)">
				  <v-btn style="font-size: 15px" v-bind="buttonsTheme" class="my-8" 
                  v-for="section in sections" v-on:click="get_Option(section.title)" :key="section.title">{{ section.title }}</v-btn>
                </v-btn-toggle>
            </v-col>
        </v-row> 
        <!-- If selected the correspondent component wil be shown and a transition will be started. And the reset_values() will be called when inside a component the resetValues is called  -->
        <transition enter-active-class="animated fadeIn" leave-active-class="animated fadeOut" mode="out-in">
            <EasyFake @resetValues="reset_values()" v-show="this.sections[0].selected "></EasyFake>
        </transition>
        <transition enter-active-class="animated fadeIn" leave-active-class="animated fadeOut" mode="out-in">
            <DifficultFake @resetValues="reset_values()" v-show="this.sections[1].selected "></DifficultFake>
        </transition>
        
        <div class="bottom-fake">
        <v-btn v-show="!this.option_selected" style="font-size: 10px" v-bind="buttonsTheme" class="my-6 mt-10" v-on:click="reset_values()" > MENU </v-btn>
        </div>
    </div>
</template>
<script>
  import EasyFake from '@/components/fake/Easy.vue'
  import DifficultFake from '@/components/fake/Difficult.vue';

  export default {
    name:'Fake',
    components:{
        EasyFake,
        DifficultFake
    },
    data: () => ({ 
        option_selected: false,
        sections: [
            {title: 'Level 1', selected:false}, 
            {title: 'Level 2',selected:false}, 
        ],
    }),
    computed:{
        buttonsTheme(){
          return this.$store.state.buttonsTheme;
        },
    },
    methods:{
        get_Option(option){
            this.option_selected = true;
            switch(option){
                case 'Level 1':
                    this.sections[0].selected = true;
                    break;
                case 'Level 2':
                    this.sections[1].selected = true;
                    break;
            }
        },
        reset_values(){
            this.option_selected = false;   
            this.sections[0].selected = false; 
            this.sections[1].selected = false; 
            this.$emit('resetValues');
        }
    }
}
</script>