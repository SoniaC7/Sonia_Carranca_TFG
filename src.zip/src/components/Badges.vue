<template>
    <div class="badges"> 
        <!-- Page to show th badges -->
        <h1 class="mb-3 mt-3"> Badges </h1>
        <div class="badge-section" >
            <div id="id_badges" class="column" v-for="badge in badges" :key="badge.id" >
                <div class="badge" style="white-space: break-spaces;">
                    {{ badge.text }} 
                    <br>
                    <div v-if="badge.earned" class="badge-img mt-2" > <!-- If the badge is earned the opacity is set to maximum, can be found in componentsStyles.css -->
                        <img :src="badge.example" >
                    </div>
                    <div v-else class="badge-img badge_not_earned mt-2" > <!-- If the badge is not earned the opacity is set to half -->
                        <img :src="badge.example" >
                    </div>
                </div>
            </div>
        </div>
        <v-container align="center" >
            <v-row align="center" style="width:100%;" no-gutters>
                <v-col
                    cols="12"
                    style="width:100%"
                >
                    <v-btn-toggle style="flex-direction: column; width: 30%;" background-color="rgb(255, 0, 0, 0)" >
                    <v-btn style="font-size: 20px" v-bind="buttonsTheme" class="my-6" v-for="section in sections" :to="section.to" :key="section.title" v-on:click=" reset()">{{ section.title }}</v-btn>
                    </v-btn-toggle>
                </v-col>
            </v-row>
        </v-container>
    </div>
</template>
<script>
  export default {
    name:'Badges',
    data: () => ({ 
        sections: [
        { title: ' Menu ', to:'/game'}
      ]
    }),
    computed:
    {
        badges(){
            return this.$store.state.badges
        },
        buttonsTheme(){
          return this.$store.state.buttonsTheme;
        }
    }, 
    methods:
    {
        reset(){
            this.$emit('resetValues'); //When going back to the menu page it calls the resetValues method from the game page.
        }
    }
  }
</script>