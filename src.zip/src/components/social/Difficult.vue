<template>  
  <div class="difficult">
    <!-- It works like Medium.vue -->
   <div v-show="!this.finish_level">
				<h1 class="mb-8 mt-6"> Select the ones you think are posted on social media</h1> 
          <div v-if="this.media_right" >
            <div class="column">
              <img id="realIdDiff" :src="this.real_image" v-on:click="increment_score_lose()"/>
            </div>
            <div class="column" >
              <img id="mediaIdDiff" :src="this.media_image" v-on:click="increment_score_win()"/>
            </div>
          </div> 
          
          <div v-else >
            <div class="column" >
              <img id="mediaIdDiff" :src="this.media_image" v-on:click="increment_score_win()"/>
            </div>
            <div class="column">
              <img id="realIdDiff" :src="this.real_image" v-on:click="increment_score_lose()"/>
            </div>
          </div>

       <div class="bottom">
          <div class="ma-2" >
            <h4> Accuracy </h4>
            <div> {{ accuracy_value }}% </div>
            <v-progress-linear
              color="green"
              v-model="accuracy_value"
              height="10"
              striped
              rounded
              style="border: 1px solid black;"
            ></v-progress-linear>
          </div>

          <br>
          <div class="btn-section">
            <v-btn v-bind:disabled="!image_clicked" v-bind="buttonsTheme" v-on:click="next()" > Next </v-btn>
          </div>

          <v-btn v-show="!this.finish_level" style="font-size: 10px" v-bind="buttonsTheme" class="my-6 mt-10" v-on:click="back_to_menu()"> MENU </v-btn>
          
       </div>
      

		</div>
			<div v-show="this.finish_level">
				<br>
				<h2> Congrats! You have finished the level </h2>
        <h3 class="mt-6"> Your accuracy was {{ this.accuracy}}</h3>
				<div v-show="this.badge_earned">
					<h2> You earned a new badge! </h2>
					<div class="img-section">
						<img :src="badges[2].example" >
					</div>
				</div>
				<v-row align="center">
          <v-col
            cols="12"
          >
              <v-btn-toggle style="flex-direction: column; width: 30%;" background-color="rgb(255, 0, 0, 0)">
              <v-btn style="font-size: 20px" v-bind="buttonsTheme" class="my-6" v-for="section in sections" :to="section.to" :key="section.title" v-on:click="back_to_menu()">{{ section.title }}</v-btn>
              </v-btn-toggle>
          </v-col>
        </v-row> 
		  </div> 
</div>
</template> 

<script>
  import InnerImageZoom from 'vue-inner-image-zoom';

  export default {
    name:'Difficult',
    data: () => ({ 
      index: 1,
      total_images: 17,
      fol_name: '',
      accuracy:0,
      num_correct_answers:0,
      total_answers:0,
      finish_level: false,
      badge_earned: false,
      media_right: false,
      image_clicked:false,

      media_image: require('@/assets/images/media/difficult/1/media.png'),
      real_image: require('@/assets/images/media/difficult/1/real.png'),

      sections: [
        { title: ' Menu ', to:'/game'}
      ] 
    }),
    computed:{
      accuracy_value(){
          return this.accuracy.toFixed();
      },
      buttonsTheme(){
          return this.$store.state.buttonsTheme;
      },
      badges(){
            return this.$store.state.badges;
      }
    }, 
    methods:{
        reset_values(){
          this.index = 1;
          this.total_images= 17;
          this.fol_name= '';
          this.accuracy= 0;
          this.total_answers= 0;
          this.num_correct_answers= 0;
          this.finish_level= false;
          this.badge_earned= false;
          this.media_right= false;
          this.image_clicked= false;

          this.media_image= require('@/assets/images/media/difficult/1/media.png');
          this.real_image= require('@/assets/images/media/difficult/1/real.png');
        },
        badge_earned_method(id){
            this.$store.commit('badge_earned',id);
        },
        back_to_menu(){
          this.reset_values();
          this.$emit('resetValues');
        },
        add_border(media_clicked){
          if(media_clicked)document.getElementById("mediaIdDiff").style.border = "2px solid black" ;
          else document.getElementById("realIdDiff").style.border = "2px solid black";
        },
        remove_borders(){
          document.getElementById("mediaIdDiff").style.border = "0px solid black";
          document.getElementById("realIdDiff").style.border = "0px solid black";
        },
        increment_score_win(){
          this.num_correct_answers += 1;
          this.set_accuracy();
          this.add_border(true);
          this.image_clicked = true;
            
        },
        increment_score_lose(){
          this.set_accuracy();
          this.add_border(false);
          this.image_clicked = true;
            
        },
        set_accuracy(){
          this.total_answers += 1;
          this.accuracy = Math.round((this.num_correct_answers / this.total_answers ) * 100);
        },
        getImageMedia(index){
            var in_string = index.toString();
            this.fol_name = require('@/assets/images/media/difficult/'+ in_string + '/media.png');
            return this.fol_name;
        },
        getImageReal(index){
            var in_string = index.toString();
            this.fol_name = require('@/assets/images/media/difficult/'+ in_string + '/real.png');
            return this.fol_name;
        },
        next(){
            
            this.remove_borders();
            this.image_clicked = false;
            this.index = this.index + 1;
            
            this.media_right= Math.random() < 0.5;

            if(this.index <= this.total_images){
                this.media_image = this.getImageMedia(this.index);
                this.real_image = this.getImageReal(this.index);
            }
            else{
                this.finish_level = true;
                if(this.accuracy == 100){
                    this.badge_earned = true;
                    this.badge_earned_method(2);
                }
            }
        }
    }
  }
</script>