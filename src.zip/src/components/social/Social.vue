<template>
    <div class="social"> 
        <h1 class="mb-3 mt-3" v-show="!this.option_selected"> Real vs Social Media</h1>
        <v-row align="center" v-show="!this.option_selected">
            <v-col
                cols="12"
            >
                <v-btn-toggle style="flex-direction: column;" background-color="rgb(255, 0, 0, 0)">
				  <v-btn style="font-size: 15px" v-bind="buttonsTheme" class="my-6" 
                  v-for="section in sections" v-on:click="get_Option(section.title)" :key="section.title">{{ section.title }}</v-btn>
                </v-btn-toggle>
            </v-col>
        </v-row> 
        <!-- If selected the correspondent component wil be shown and a transition will be started. And the reset_values() will be called when inside a component the resetValues is called  -->
        <transition enter-active-class="animated fadeIn" leave-active-class="animated fadeOut" mode="out-in">
            <Easy @resetValues="reset_values()" v-show="this.sections[0].selected "></Easy>
        </transition>
        <transition enter-active-class="animated fadeIn" leave-active-class="animated fadeOut" mode="out-in">
            <Medium @resetValues="reset_values()" v-show="this.sections[1].selected "></Medium>
        </transition>
        <transition enter-active-class="animated fadeIn" leave-active-class="animated fadeOut" mode="out-in">
            <Difficult @resetValues="reset_values()" v-show="this.sections[2].selected "></Difficult>
        </transition>

        <div class="bottom-social">
            <v-btn v-show="!this.option_selected" style="font-size: 10px" v-bind="buttonsTheme" class="my-6 mt-10" v-on:click="reset_values()" > MENU </v-btn>
        </div>
    </div>

</template>
<script>
import Easy from '@/components/social/Easy.vue'
import Medium from '@/components/social/Medium.vue'
import Difficult from '@/components/social/Difficult.vue';

export default {
    name:'Social',
    components:{
        Easy,
        Medium,
        Difficult
    },
    data: () => ({ 
        option_selected: false,
        sections: [
            {title: 'Level 1', selected:false}, 
            {title: 'Level 2',selected:false}, 
            {title: 'Level 3',selected:false}
        ],
    }),
    computed:{
        buttonsTheme(){
          return this.$store.state.buttonsTheme;
        },
    },
    methods:{
        get_Option(option){
            this.option_selected = true;
            switch(option){
                case 'Level 1':
                    this.sections[0].selected = true;
                    break;
                case 'Level 2':
                    this.sections[1].selected = true;
                    break;
                case 'Level 3':
                    this.sections[2].selected = true;
                    break;
            }
        },
        reset_values(){
            this.option_selected = false;   
            this.sections[0].selected = false; 
            this.sections[1].selected = false; 
            this.sections[2].selected = false; 
            this.$emit('resetValues');
        }
    }
}
</script>