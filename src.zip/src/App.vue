<template>
  <v-app id="app">
      <v-main> 
        <!-- Set that has all the background loupes to animate -->
        <div class="set">
          <div><img :src="this.loupe"></div> 
          <div><img  :src="this.loupe"></div>
          <div><img  :src="this.loupe"></div>
          <div><img  :src="this.loupe"></div>
          <div><img  :src="this.loupe"></div>
          <div><img  :src="this.loupe"></div>
          <div><img  :src="this.loupe"></div>
          <div><img  :src="this.loupe"></div>
        </div>
        <transition name="router-anim" enter-active-class="animated flipInY" leave-active-class="animated flipOutY" mode="out-in">
          <router-view></router-view>  <!-- Router-Views enables to navigate from page to page -->
        </transition>
      </v-main>
  </v-app>
</template>
 <!-- All other styles cna be found in the assets/tyles/componentStyles.css file -->
<style scoped>
#app {
  font-family: 'American Typewriter','Optima','Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  align-self: center;
  align-content: center;
  justify-self: center;
  justify-content: center;
  color: #1f252b;
  background-image: url('assets/images/background.png');
  background-size: cover;
  height: 100%;
  max-width: 1920px;
  display: block;
  margin: 0 auto;  
}
</style>
 
<script>
  export default {
    data: ()=> ({
      loupe: require('@/assets/images/lupa.png'),
    }),
      computed: {
        theme () {
          return(this.$vuetify.theme.dark) ? 'dark' : 'light'
        },
      }
  }
</script>