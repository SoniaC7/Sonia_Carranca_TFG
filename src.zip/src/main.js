import Vue from 'vue'
import App from './App.vue'
import router from './router' //router contains the route to all pages
import store from './store' //store contains shared information accessed by all pages
import vuetify from './plugins/vuetify' //vuetify is used for graphical/style aspects
import '@/assets/styles/componentsStyles.css' 

Vue.config.productionTip = false;

new Vue({
  router,
  store,
  vuetify,
  render: h => h(App)
}).$mount('#app')
