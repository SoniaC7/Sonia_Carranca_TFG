
<template>
  <v-card class="home" elevation="24" rounded="xl" outlined color="#d4d3d3"> 
    <h1> Become a master detective </h1>
    <h2> Discover the truth about social media</h2>
      <HomePage> </HomePage>
  </v-card>
</template>
<script>
// @ is an alias to /src
import HomePage from '@/components/HomePage.vue'
export default {
  name: 'Home',
  components: {
    HomePage
  }
}
</script>
