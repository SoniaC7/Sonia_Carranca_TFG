<template>
  <div class="tips">
    <!-- Contains information about the tips-->
    <v-card elevation="24" rounded="xl" outlined color="#d4d3d3"> 
        <h1 class="mb-3 mt-3"> Let's start by reviewing some tips </h1>
        <div class="column-tips" v-for="tip in tips" :key="tip.id"> <!-- Iterate throguh all tips and show them-->
          <div style="white-space: break-spaces;"> 
            {{ tip.text }} 
            <br>
              <img :src="tip.example" > 
          </div>
        </div>
        <div class="bottom-tips">
          <h2 class="mb-3 mt-9"> Great! Let's play!</h2>
          <v-btn style="font-size: 15px" v-bind="buttonsTheme" class="mb-2" :to="section[0].to"> {{ section[0].title }} </v-btn>
        </div>
    </v-card>
    </div>
</template>
<script>
  export default {
    name:'Tips',
    data: () => ({ 
      section: [
          {title:'Play', to:"/game"}
        ],
      tips: [
            {
                id: 0,
                text: "Check the background for bent or distorted parts because when something is \"pushed\" to look thinner the background may appear bent as well",
                example: require("../assets/images/tips/bent.png")
            },{
                id:1,
                text: "Check the shadows",
                example: require("../assets/images/tips/shadow.png")
            },{
                id:2,
                text: "Be aware that a body may look very different depending on the pose",
                example: require("../assets/images/tips/pose.png")
            }
        ]
    }),
    computed:{
      buttonsTheme(){
          return this.$store.state.buttonsTheme;
        }
    }
  }
</script>