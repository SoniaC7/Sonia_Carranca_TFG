<template>
  <div class="game" >
    <v-card elevation="24" rounded="xl" outlined color="#d4d3d3"> 
        <h1 class="pt-9" v-show="!this.option_selected "> Become a master detective  </h1>
        <h2 class="mb-3 mt-2" v-show="!this.option_selected "> Discover the truth about social media</h2>
        <v-row align="center" v-show="!this.option_selected ">
          <v-col
            cols="12"
          >
              <v-btn-toggle style="flex-direction: column;" background-color="rgb(255, 0, 0, 0)">
              <v-btn style="font-size: 15px" v-bind="buttonsTheme" class="my-8" 
              v-for="section in sections" v-on:click="get_Option(section.title)" :key="section.title">{{ section.title }}</v-btn>
              </v-btn-toggle>
          </v-col>
        </v-row> 
        <!-- 3 components that will be shown if selected, and when inside a component the resetValues method is called then the reset_values() will be called which resets values to show the correct information if the users goes back to this page -->
        <transition enter-active-class="animated fadeIn" mode="out-in">
          <Social @resetValues="reset_values()" v-show="this.sections[0].selected"></Social>
        </transition>
        <transition enter-active-class="animated fadeIn" mode="out-in">
          <Fake @resetValues="reset_values()" v-show="this.sections[1].selected"></Fake>
        </transition>
        <transition enter-active-class="animated fadeIn" mode="out-in">
          <Badges @resetValues="reset_values()" v-show="this.sections[2].selected"></Badges>
        </transition>
      
         <v-btn v-show="!this.option_selected " style="font-size: 10px" v-bind="buttonsTheme" class="my-6 mt-10" v-on:click="back_to_menu()"> MENU </v-btn>
    </v-card>
  </div>
</template>
<script>
  import Social from '@/components/social/Social.vue'
  import Fake from '@/components/fake/Fake.vue'
  import Badges from '@/components/Badges.vue'

  export default {
    name:'Game',
    components:{
        Social,
        Fake,
        Badges
    },
    data: () => ({ 
      option_selected: false,
      sections: [
          {title:'Real vs Social Media', selected:false},
          {title:'Fake photos', selected:false},
          {title:'Badges', selected:false},
        ],
    }),
    computed:{
        buttonsTheme(){
          return this.$store.state.buttonsTheme;
        },
    },
    methods:{
      reset_values(){
        this.option_selected = false;   

        this.sections[0].selected = false; 
        this.sections[1].selected = false; 
        this.sections[2].selected = false; 
      },
      get_Option(section){
        this.option_selected = true;
        
        switch(section){
          case 'Real vs Social Media':
            this.sections[0].selected = true;
            break;
          case 'Fake photos':
            this.sections[1].selected = true;
            break;
          case 'Badges':
            this.sections[2].selected = true;
            break;
        }
      },
      back_to_menu(){
        this.reset_values();
        this.$router.push("/");
      }
    }
  }
</script>