<template>
  <div class="quiz">
    <!-- Contains information about the quiz -->
    <v-card elevation="24" rounded="xl" outlined color="#d4d3d3"> 
    <h1 class="mb-3 mt-3"> Quiz </h1>
			<div v-for="(question,index) in questions" :key="question.id"> <!-- Iterate through every question and show one question at a time -->
				<div v-show="index === questionIndex">
					<h2 style="font-size:18px">{{ question.text }}</h2>
					
          <ol style="list-style-type: none">
						<li class="mt-6  mr-6 mb-6" style="font-size:25px" v-for="response in question.responses" :key="response.id_r">
							<label>
                 <!-- Store answers to the u_responses -->
								<input type="radio" 
                  v-on:click="answer_clicked = true"
									v-bind:value="response.correct" 
									v-bind:name="index" 
									v-model="u_responses[index]"
                  > {{response.text}}
							</label>
						</li>
					</ol>
          <div class="bottom-quiz">
            <div>
              <v-btn v-bind:disabled="!answer_clicked" style="font-size: 15px" v-bind="buttonsTheme" class="mb-6 black--text" v-on:click="next"> Next question </v-btn>
            </div>
            <div>
              <v-btn style="font-size: 10px" v-bind="buttonsTheme" :to="sections[2].to"> MENU </v-btn>
            </div>
          </div>
				</div>
			</div>
       <!-- Information to show when questionnaire is finished -->
			<div v-show="questionIndex === questions.length">
				<h2 class="mb-6 mt-6">Congrats! You finished the quiz</h2>
        <!-- If the score is less than 70% the tips are shown, it can be changed to be more flexible -->
					<div v-if="total_score < 0.7">
						<h2 class="mb-10 mt-10"> Here's some tips you can use to identify fake photos</h2>
            <v-btn style="font-size: 15px" v-bind="buttonsTheme" :to="sections[0].to"> {{ sections[0].title }}</v-btn>
					</div>
					<div v-else>
						<h2 class="mb-6 mt-6">Let's play!</h2>
            <v-btn style="font-size: 15px" v-bind="buttonsTheme" :to="sections[1].to"> {{ sections[1].title }}</v-btn>
					</div>
				
			</div>
    </v-card>
  </div>
</template>
<script>
  export default {
    name:'Quiz',
    data: () => ({ 
      answer_clicked: false,
      questions: [
        {
            id:0,
            text: "When you see a photo you like in social media how possible is it for you to visit the users' profile?",
            responses: [{id_r:0,text: "Not possible at all -- 1", correct: false}, {id_r:1,text: "2", correct: false},{id_r:2,text: "3", correct: true},{id_r:3,text: "4", correct: true},{id_r:4,text: "5 -- Very possible", correct: true}]
        },{
            id:1,
            text: "How much time do you spend looking at each photo?",
            responses: [{id_r:0,text: "Not much -- 1", correct: false}, {id_r:1,text: "2", correct: false},{id_r:2,text: "3", correct: false},{id_r:3,text: "4", correct: false},{id_r:4,text: "5", correct: false},{id_r:5,text: "6", correct: true}, {id_r:6,text: "7", correct: true},{id_r:7,text: "8", correct: true},{id_r:8,text: "9", correct: true},{id_r:9,text: "10 -- Quite a lot", correct: true}]
        },{
            id:2,
            text: "How much time do you spend on social media in a day?",
            responses: [{id_r:0,text: "Less than an hour -- 1", correct: true}, {id_r:1,text: "2", correct: true},{id_r:2,text: "3", correct: true},{id_r:3,text: "4", correct: true},{id_r:4,text: "5", correct: false},{id_r:5,text: "6", correct: false}, {id_r:6,text: "7 -- More than 7", correct: false}]
        },{
            id:3,
            text: "How satisfied are you with your body?",
            responses: [{id_r:0,text: "Not satisfied", correct: false}, {id_r:1,text: "A little satisfied", correct: false},{id_r:2,text: "Somewhat satisfied", correct: true},{id_r:3,text: "Satisfied", correct: true},{id_r:4,text: "Very satisfied", correct: true}]
        },{
            id:4,
            text: "From all the people you follow, how many are models or influencers?",
            responses: [{id_r:0,text: "0%", correct: true}, {id_r:1,text: "25%", correct: true},{id_r:2,text: "50%", correct: true},{id_r:3,text: "75%", correct: false},{id_r:4,text: "100%", correct: false}]
        },{
            id:5,
            text: "Do you know what body dysmorphia is?",
            responses:[{id_r:0,text: "Not at all -- 1", correct: false}, {id_r:1,text: "2", correct: false},{id_r:2,text: "3", correct: true},{id_r:3,text: "4", correct: true},{id_r:4,text: "5 -- I know it very well", correct: true}]
        }
      ],
      questionIndex: 0,
      u_responses: Array(6).fill(false),
      sections: [
        { title: 'Tips', to:'/tips'},
        { title: 'Game', to:'/game'},
        { title: 'Home', to:'/'}
        ]
    }),
    computed:{
        total_score(){
            return this.u_responses.filter(function(val){return val}).length / 6; //It returns the number of "true" values out of the 6 questions
        },
        buttonsTheme(){
          return this.$store.state.buttonsTheme;
        }
    },
    methods:{
        next: function() {
            this.questionIndex++;
            this.answer_clicked = false;
        }
    }
  }
</script>